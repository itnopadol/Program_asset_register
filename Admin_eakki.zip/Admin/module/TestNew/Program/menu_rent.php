<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Menu</title>
</head>
<body>
<style type="text/css">
.listcircle {
	list-style-type: disc;
}
</style></head>
<h2>ระบบยืม/คืน Spare parts</h2>
<ol>
  <li class="listcircle"><a href='list_spare.php'>จัดการวัสดุ-อุปกรณ์</a></li>
  <li class="listcircle"><a href='take.php'>ประวัติรายการรับ</a></li>
  <li class="listcircle"><a href='list_lend.php'>จัดทำรายการเบิก</a></li>
  <li class="listcircle"><a href='lend.php'>ประวัติรายการเบิก</a></li>
  <li class="listcircle"><a href='list_category_spare.php'>จัดการหมวดหมู่</a></li>
  <li class="listcircle">รายงาน</a></li>

</ol>
<hr>
</body>
</html>