<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Menu</title>
</head>
<body>
<style type="text/css">
.listcircle {
	list-style-type: disc;
}
</style></head>
<h2>Menu ของโปรแกรม</h2>
<ol>
  <li class="listcircle"><a href='list_asset.php'>จัดการสินทรัพย์ </a></li>
  <li class="listcircle"><a href='list_category.php'>จัดการหมวดหมู่สินทรัพย์</a></li>
  <li class="listcircle"><a href='list_status.php'>ตรวจสอบสถานะ</a></li>
  <li class="listcircle"><a href='menu_rent.php'>การรับเบิกวัสดุ</a></li>
  <li class="listcircle">จัดการ User ผู้ใช้งาน</li>
  <li class="listcircle">รายงานข้อมูลสินทรัพย์</li>
</ol>
<hr>
</body>
</html>