<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Login</title>
<link href="../../CSS/Login.css" rel="stylesheet" type="text/css">
<link href="../../layout.css" rel="stylesheet" type="text/css">
</head>
<style type="text/css">
h2{
	line-height:35px;
	margin:0px 0;
	border-radius:-1px;
	padding:10px 30px;
	background-color:#005ce6;
	font-size:2em;
	color:#FFFAFA;
	padding:15px;
	font-family:"TH Sarabun New", "Tw Cen MT";
}
</style>
<body>
<form method="post" action="index.php?module=7&action=3" class="menu" >
<!--<P><center><img src="img/if_user_accounts.png" style="width:118px;height:118px;" >
</center></P>-->
<h2 align="center">Login</h2>
<h4><P>Username: <input type="text" name="username" id="uses" required="required" ></P>
<P>Password: <input type="password" name="passwd" id="pass" required="required" ></P>
<center><button type="submit" name="" value="Login" style="width:auto;">Login</button>
<button type="reset" name="" value="Cancel" class="b2" style="width:auto;">Cancel</button>
</h4></center>
</form>

	<script src="../../JS/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
	<script src="../../JS/popper.min.js" crossorigin="anonymous"></script>
	<script src="../../JS/bootstrap.min.js" crossorigin="anonymous"></script>
</body>
</html>