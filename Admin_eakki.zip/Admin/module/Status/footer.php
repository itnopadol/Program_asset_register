</div><!--/Container-->
<script type="text/javascript" src="../../JS/jquery.min.js"></script>
<script type="text/javascript" src="../../JS/bootstrap.min.js"></script>
<script type="text/javascript" src="../../JS/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../../JS/dataTables.bootstrap.js"></script>
<script type="text/javascript" src="../../JS/app.js"></script>
</body>
</html>