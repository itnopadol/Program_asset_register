<?php 
	include("../../Funtion/connect.php");
	//$con = connect_db();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<title>Update Modal</title>
<meta http-equiv="Content-Type" 
content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="../../CSS/bootstrap.css" charset="utf-8"> 
<link rel="stylesheet" href="../../CSS/font-awesome.min.css" 
charset="utf-8">
<link rel="stylesheet" href="../../CSS/dataTables.bootstrap4.min.css">
</head>
<body>
<!--</body>
</html>-->
	<div class="container">
    
    