<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<head>
<link href="../../CSS/style.css" rel="stylesheet" type="text/css" />
</head> 
<body>
<div id="welcome" class=" fonSize">
				<H4>ยินดีต้อนรับเข้าหน้าเพจของฉัน</H4>
                <p><img src="./img/h4GyY2823.png" style="width:600px;height:221px;"></p>
			</div>
</body>