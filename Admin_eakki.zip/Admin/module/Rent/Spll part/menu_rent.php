<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Menu</title>
</head>
<body>
<style type="text/css">
.listcircle {
	list-style-type: disc;
}
</style></head>
<h2>STOCK</h2>
<ol>
  <li class="listcircle"><a href='list_rent.php'>รายการวัสดุ-อุปกรณ์</a></li>
  <li class="listcircle">รายการเบิก</a></li>
  <li class="listcircle">รายการรับ</a></li>
  <li class="listcircle">รายงาน</a></li>

</ol>
<hr>
</body>
</html>