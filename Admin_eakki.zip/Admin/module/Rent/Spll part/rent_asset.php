<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ยืม/คืน สินทรัพย์</title>
</head>
<body>
<form method="post" action="" name="FormRent">
<input  type="hidden" name="" value="" />
</form>
<?php
echo "<table border = 1 align='center'>";
	echo "<th>No</th>";
	echo "<th>รหัสพนักงาน</th>";
	echo "<th>ชื่อพนักงาน</th>";
	echo "<th>ชื่อสินทรัพย์</th>";
	echo "<th>วันที่ยืม</th>";
	
?>
</body>
</html>