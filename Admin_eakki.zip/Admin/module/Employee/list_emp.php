<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>เพิ่มข้อมูลสินทรัพย์</title>
<!--<link href="../../CSS/CSS2.css" rel="stylesheet" type="text/css">-->
<style type="text/css">
body {
	font-family:"TH Sarabun New", "Tw Cen MT";
	font-size:24px;		
}
.bottomsize {
	font-size:20px;
	font-family:"TH Sarabun New", "Tw Cen MT";
}
</style>
</head>
<title>ร้านจิตรเจริญ</title>
<center>
	<table class="table-height"  >
		<tr><td colspan=2 class="width-main-content3" style="background-color:#666666;">
			<span class='button-edit'>
<center><a href='index.php?module=admin&action=edit_employee_form&id=010'><button type='button' class="bottomsize" style='font-size:22px;' >แก้ไขข้อมูลทั่วไป</button></a></span>
			<input type='hidden' name='user_id' id='USER_id' value='00001'>	<span class='button-edit'><button type='button' class="bottomsize" style='font-size:22px;' data-toggle='modal' data-target='#deleted' onclick=delone('010',this) user_idDel1='010'>ลบรายชื่อ</span>
			</button></a><span class='button-edit'>
		    <button class="bottomsize" type="button"><a href='module/admin/report_employee.php?user_id=010' target='_blank'><span style="font-size:22px;">รายงาน</span></button>
			</span>
			</div>
		</td></tr>
		<tr><td class="width-main-content1" >รูป</td><td class="width-main-content2"><img src='dbms.jpg' width=100px height=100px></td></tr>
		<tr><td class="width-main-content1">ชื่อผู้ใช้งาน </td><td class="width-main-content2">010</td></tr>
		<tr><td class="width-main-content1">รหัสผ่าน</td><td class="width-main-content2">Katay_Thantip</td></tr>
		<tr><td class="width-main-content1">ชื่อพนักงาน </td><td class="width-main-content2">ธารทิพย์ เศรษฐกิจ</td></tr>
		<tr><td class="width-main-content1">แผนก</td><td class="width-main-content2">IT</td></tr>
		<tr><td class="width-main-content1">เบอร์โทรติดต่อ </td><td class="width-main-content2">0946365086</td></tr>    
        
  <table class="table-height" >
		<tr><td colspan=2 class="width-main-content3" style="background-color:#666666;">
			<div class="edit-flaodr">
			<span class='button-edit'>
<center><a href='index.php?module=admin&action=edit_employee_form&id=010'><button type='button' class="bottomsize" style='font-size:22px;' >แก้ไขข้อมูลทั่วไป</button></a></span>
			<input type='hidden' name='user_id' id='USER_id' value='00001'>	<span class='button-edit'><button type='button' class="bottomsize" style='font-size:22px;' data-toggle='modal' data-target='#deleted' onclick=delone('010',this) user_idDel1='010'>ลบรายชื่อ</span>
			</button></a><span class='button-edit'>
		    <button class="bottomsize" type="button"><a href='module/admin/report_employee.php?user_id=010' target='_blank'><span style="font-size:22px;">รายงาน</span></button>
			</span>
	
			</div>
		</td></tr>
		<tr><td class="width-main-content1">รูป</td><td class="width-main-content2"><img src='dbms.jpg' width=100px height=100px></td></tr>
		<tr><td class="width-main-content1">ชื่อผู้ใช้งาน </td><td class="width-main-content2">010</td></tr>
		<tr><td class="width-main-content1">รหัสผ่าน</td><td class="width-main-content2">Katay_Thantip</td></tr>
		<tr><td class="width-main-content1">ชื่อพนักงาน </td><td class="width-main-content2">ธารทิพย์ เศรษฐกิจ</td></tr>
		<tr><td class="width-main-content1">แผนก</td><td class="width-main-content2">IT</td></tr>
		<tr><td class="width-main-content1">เบอร์โทรติดต่อ </td><td class="width-main-content2">0946365086</td></tr>
  </table>            

</body>
</html>
