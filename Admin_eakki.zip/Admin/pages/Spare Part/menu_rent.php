<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Menu</title>
</head>
<body>
<style type="text/css">
.listcircle {
	list-style-type: disc;
}
</style></head>
<h2>ระบบยืม/คืน Spare parts</h2>
<ol>
  <li class = " listcircle "><a href = ' list_spare.php '>จัดการวัสดุ-อุปกรณ์</a> </li>
  <li class = " listcircle "><a href = ' index_sp.php '>จัดทำรายการเบิก</a> </li>
  <li class = " listcircle "><a href = ' take.php '>รายการรับเข้า</a> </li>
  <li class = " listcircle "><a href = ' lend.php '>รายการเบิก</a> </li>
  <li class = " listcircle "><a href = ' render.php '>รับคืนวัสดุ-อุปกรณ์</a> </li>
  <li class = " listcircle "><a href = ' send.php '>ประวัติรับคืนวัสดุ-อุปกรณ์</a> </li>
  <li class = " listcircle "><a href = ' list_category_spare.php '>จัดการหมวดหมู่</a> </li>
  <li class = " listcircle "><h3>-----รายงาน-----</li></h3>
       <ol>
        <li class = " listcircle "><a href = 'report/repost_spart1.php'>รายงานยอดคงเหลือ</a> </li>
        <li class = " listcircle "><a href = 'report/repost_take1.php  '>รายงานการรับเข้าวัสดุ</a> </li>
        <li class = " listcircle "><a href = 'report/report_lend1.php'>รายงานการเบิก</a> </li>
        <li class = " listcircle "><a href = 'report/report_send1.php '>รายงานคืนวัสดุ</a> </li>
  	   </ol>
</ol>
<hr>
</body>
</html>