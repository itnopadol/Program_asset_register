<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<h2>รายงาน REPOET</h2>
<ol>
  <li class = " listcircle "><a href = '  '>รายงานสรุปยอดคงเหลือวัสดุ / อุปกรณ์</a> </li>
  <li class = " listcircle "><a href = '  '>รายงานการเบิก</a> </li>
  <li class = " listcircle "><a href = '  '>รายงานรับคืนวัสดุ-อุปกรณ์</a> </li>
  <li class = " listcircle "><a href = '  '>งานการรับวัสดุเข้า</a> </li>


</ol>
<hr>
<body>
</body>
</html>