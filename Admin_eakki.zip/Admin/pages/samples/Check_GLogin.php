<?php
session_start();
if(isset($_POST['Username'])){
	$ch = curl_init();
	// Disable SSL verification
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	// Will return the response, if false it print the response
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	// Set the url
	curl_setopt($ch, CURLOPT_URL,"http://venus:9000/login?usercode=".$_POST['Username']."&password=".$_POST['Password']."&appid=6");
	// Execute
	$result=curl_exec($ch);
	// Closing
	curl_close($ch);
	// Will dump a beauty json :3
	//var_dump(json_decode($result, true));
	$data = json_decode($result, true);
	@$datauser = $data['data'];
	$x = $data['data']['menu']['0']['is_create'];
	
	$username = $_POST['Username'];
	$passwd = $_POST['Password'];
	$usercode = $datauser['usercode'];
	$password = $datauser['password'];
	$Level = (string)$x;
	echo "";
	/*if($username == $usercode and $passwd == $password){
		$_SESSION['valid_user'] = $usercode;
		$_SESSION['user_Level'] = $Level;
		echo "<script>window.location='../../index.html'</script>";
	}
	else{
		echo "<script>alert('กรุณากรอก Username และ Password ให้ถูกต้อง')</script>";
		echo "<script>window.location='../../index.php'</script>";*/
		/*echo "<script>window.location='index.php?module=7&action=2'</script>";*/
	//}
}
?>