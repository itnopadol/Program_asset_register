// JavaScript Document
$(document).ready(function() {
    $('.datatable').dataTables();
});